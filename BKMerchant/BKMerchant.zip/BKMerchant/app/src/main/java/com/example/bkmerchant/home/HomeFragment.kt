package com.example.bkmerchant.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.bkmerchant.R
import com.example.bkmerchant.databinding.HomeFragmentBinding
import com.example.bkmerchant.databinding.LoginFragmentBinding
import com.example.bkmerchant.login.LoginViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class HomeFragment : Fragment() {
    private lateinit var binding: HomeFragmentBinding
    private lateinit var viewModel: LoginViewModel
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        binding = HomeFragmentBinding.inflate(inflater, container, false)

        val currentUser = firebaseAuth.currentUser;

        if (null != currentUser) {
            binding.welcomeText.text = "Welcome,\n " + currentUser.email
        } else {
            binding.welcomeText.text = "Error occured"
        }
        binding.menuText.setOnClickListener { navigateToMenuFragment() }
        binding.logoutButton.setOnClickListener { logout() }
        binding.bottomNav.setOnNavigationItemSelectedListener { item ->
            bottomNavigationItemSelected(item)
        }
        return binding.root
    }

    private fun bottomNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_account -> navigateToMenuFragment()
        }
        return true
    }

    private fun navigateToMenuFragment() {
        findNavController().navigate(R.id.menuFragment)
    }

    fun logout() {
        firebaseAuth.signOut()
        navigateToLoginFragment()
    }

    fun navigateToLoginFragment() {
        findNavController().navigate(R.id.loginFragment)
    }
}