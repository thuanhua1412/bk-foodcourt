package com.example.bkmerchant.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.bkmerchant.R
import com.example.bkmerchant.databinding.LoginFragmentBinding
import com.google.firebase.auth.FirebaseAuth

class LoginFragment: Fragment(){
    companion object {
        const val TAG = "LoginFragment"
        const val SIGN_IN_RESULT_CODE = 1001
    }

    private lateinit var binding: LoginFragmentBinding
    private lateinit var viewModel: LoginViewModel
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()

        if (firebaseAuth.currentUser != null) {
            navigateToHomeFragment()
        }

        binding = LoginFragmentBinding.inflate(inflater, container, false)
        viewModel = LoginViewModel()
        binding.loginButton.setOnClickListener { login() }
        binding.registerTextView.setOnClickListener { navigateToRegisterFragment() }

        return binding.root;
    }

    fun login() {
        val email = binding.emailText.text.toString()
        val password = binding.passwordText.text.toString()
        if (email.isEmpty()) {
            binding.emailText.setError("Empty email")
            binding.emailText.requestFocus()
        }
        else if (password.isEmpty()) {
            binding.passwordText.setError("Empty password")
            binding.passwordText.requestFocus()
        }
        else {
            firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener {task ->
                if (task.isSuccessful()) {
                    Toast.makeText(context, "Login successfull", Toast.LENGTH_SHORT).show()
                    navigateToHomeFragment()
                } else {
                    Toast.makeText(context, "Login failed, please try again", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun navigateToRegisterFragment() {
        findNavController().navigate(R.id.registerFragment)
    }

    fun navigateToHomeFragment() {
        findNavController().navigate(R.id.homeFragment)
    }
}