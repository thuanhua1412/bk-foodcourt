package com.example.bkmerchant.menu

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.view.menu.MenuView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.bkmerchant.databinding.MenuItemBinding

class MenuItemAdapter(private val viewModel: MenuViewModel): ListAdapter<Category, MenuItemAdapter.MenuItemViewHolder>(MenuItemDiffCallback()) {

    class MenuItemViewHolder private constructor(val binding: MenuItemBinding): RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Category, viewModel: MenuViewModel) {
            binding.category = item
            binding.viewModel = viewModel
        }

        companion object {
            fun from(parent: ViewGroup): MenuItemViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = MenuItemBinding.inflate(layoutInflater, parent, false)

                return MenuItemViewHolder(binding)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuItemViewHolder {
        return MenuItemViewHolder.from(parent)
    }

    override fun onBindViewHolder(holder: MenuItemViewHolder, position: Int) {
        val item = getItem(position)

        holder.bind(item, viewModel)
    }
}

class MenuItemDiffCallback : DiffUtil.ItemCallback<Category>() {
    override fun areItemsTheSame(oldItem: Category, newItem: Category): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Category, newItem: Category): Boolean {
        return oldItem == newItem
    }
}