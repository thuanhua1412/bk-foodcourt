package com.example.bkmerchant.menu

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.bkmerchant.databinding.MenuFragmentBinding
import com.firebase.ui.firestore.FirestoreRecyclerOptions
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class MenuFragment : Fragment() {

    companion object {
        const val TAG = "MenuFragment"
    }

    private lateinit var binding: MenuFragmentBinding
    private lateinit var viewModel: MenuViewModel
    private lateinit var adapter: MenuItemAdapter
    private lateinit var madapter: NewMenuAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)

        viewModel = ViewModelProvider(this).get(MenuViewModel::class.java)
        adapter = MenuItemAdapter(viewModel)

        binding = MenuFragmentBinding.inflate(inflater, container, false)
        binding.fabAddDish.setOnClickListener {onAddDish("")}
        binding.fabAddCategory.setOnClickListener {onAddCategory("")}

        binding.lifecycleOwner = this
//        binding.menuItemRecycler.adapter = adapter

        setupRecycler()

        viewModel.menu.observe(viewLifecycleOwner, Observer { list->
            adapter.submitList(list)
        })

        viewModel.openCategoryEvent.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                onAddCategory(it)
                viewModel.openCategoryEvent.value = null
            }
        })

//        FirebaseFirestore.getInstance().collection("category")
//            .get()
//            .addOnSuccessListener { querySnapshot ->
//                var itemList: String = ""
//                for (queryDocument in querySnapshot) {
//                    val item = queryDocument.toObject(Category::class.java)
//                    itemList += queryDocument.getString("name") + "\n"
//                }
//                binding.textView.text = itemList
//            }
//            .addOnFailureListener {
//                Log.w("Menu Fragment", "Error happen:v")
//            }

        return binding.root
    }

    fun onAddCategory(id: String) {
        val action = MenuFragmentDirections.actionMenuFragmentToCategoryFragment()
        action.id = id
        findNavController().navigate(action)
    }

    fun onAddDish(id: String) {
        val action = MenuFragmentDirections.actionMenuFragmentToDishFragment()
        action.id = id
        findNavController().navigate(action)
    }

    fun setupRecycler() {
        val query: Query = FirebaseFirestore.getInstance().collection("category")
        val options = FirestoreRecyclerOptions.Builder<Category>()
            .setQuery(query, Category::class.java)
            .build()

        madapter = NewMenuAdapter(options, viewModel, viewLifecycleOwner)
        binding.menuItemRecycler.adapter = madapter
    }

    override fun onStart() {
        super.onStart()
        madapter.startListening()
    }

    override fun onStop() {
        super.onStop()
        madapter.stopListening()
    }
}