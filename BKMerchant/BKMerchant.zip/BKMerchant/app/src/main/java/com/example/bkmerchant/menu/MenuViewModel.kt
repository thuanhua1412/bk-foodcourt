package com.example.bkmerchant.menu

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class MenuViewModel : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()
    private lateinit var menuListener: ListenerRegistration

    companion object {
        const val TAG = "MenuViewModel"
    }

    init {
        Log.d("MenuViewModel", "Create view model")
    }

    var menu = MutableLiveData<List<Category>>()

    val openCategoryEvent = MutableLiveData<String>()
    val openDishEvent = MutableLiveData<String>()

    init {
        menuListener = firestore.collection("category")
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if (firebaseFirestoreException != null) {
                    Log.d("Menu Fragment", firebaseFirestoreException.toString())
                } else {
                    if (querySnapshot != null) {
                        val itemList: MutableList<Category> = mutableListOf()
                        for (queryDocument in querySnapshot) {
                            val item = queryDocument.toObject(Category::class.java)
                            item.id = "category/" + queryDocument.id
                            itemList.add(item)
                        }
                        menu.value = itemList
                    }
                }
            }
    }

    override fun onCleared() {
        super.onCleared()
        menuListener.remove()
    }

    fun deleteItem(id: String) {
        Log.i(TAG, "id: $id")
        firestore.document(id).delete()
            .addOnSuccessListener {
                Log.i(TAG, "delete item success")
            }
            .addOnSuccessListener {
                Log.i(TAG, "delete item fail\nid: $id")
            }
    }

    fun openCategory(id: String) {
        openCategoryEvent.value = id
    }

    fun openDish(id: String) {
        openDishEvent.value = id
    }

}