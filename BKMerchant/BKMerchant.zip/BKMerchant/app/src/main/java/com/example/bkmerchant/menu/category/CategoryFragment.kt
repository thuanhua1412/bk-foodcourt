package com.example.bkmerchant.menu.category

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.bkmerchant.R
import com.example.bkmerchant.databinding.CategoryFragmentBinding
import com.google.firebase.firestore.FirebaseFirestore

class CategoryFragment : Fragment() {
    companion object {
        const val TAG = "CategoryFragment"
    }

    private lateinit var binding: CategoryFragmentBinding
    private lateinit var firestore: FirebaseFirestore
    private lateinit var viewModel: CategoryViewModel
    private lateinit var viewModelFactory: CategoryViewModelFactory

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)

        val args = CategoryFragmentArgs.fromBundle(requireArguments())
        viewModelFactory = CategoryViewModelFactory(args.id)
        viewModel = ViewModelProvider(this, viewModelFactory).get(CategoryViewModel::class.java)

        firestore = FirebaseFirestore.getInstance()

        binding = CategoryFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.viewModel = viewModel

        viewModel.navigateToMenuFragment.observe(viewLifecycleOwner, Observer {
            if (it == true) {
                navigateToMenuFragment()
            }
        })

        viewModel.nameFieldError.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                binding.categoryNameText.setError(it)
            }
        })

        return binding.root
    }

    fun navigateToMenuFragment() {
        findNavController().navigate(R.id.menuFragment)
    }
}