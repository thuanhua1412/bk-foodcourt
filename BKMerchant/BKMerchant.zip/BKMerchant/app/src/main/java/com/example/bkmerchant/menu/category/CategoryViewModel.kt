package com.example.bkmerchant.menu.category

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bkmerchant.menu.Category
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class CategoryViewModel(val id: String): ViewModel() {
    companion object {
        const val TAG = "CategoryViewModel"
    }

    private val firestore = FirebaseFirestore.getInstance()

    var name = MutableLiveData("")

    var nameFieldError = MutableLiveData<String>()

    var navigateToMenuFragment = MutableLiveData<Boolean>()

    init {
        Log.d(TAG, "Create ViewModel")
        if (id.isNotEmpty()) {
            firestore.document(id).get()
                .addOnSuccessListener {
                    name.value = it.getString("name").toString()
                    Log.i(TAG, "success: name")
                    Log.i(TAG, "success: $id")
                }
                .addOnFailureListener {
                    Log.d(TAG, it.toString())
                }
        }
    }

    fun saveCategory() {
        val catName = name.value ?: ""

        if (catName.trim().isNotEmpty()) {
            firestore.collection("category")
                .whereEqualTo("name", name.value)
                .limit(1)
                .get()
                .addOnSuccessListener {
                    if (it.isEmpty()) {
                        val category = Category(name = catName)
                        if (id.isNotEmpty()) {
                            updateCategory(category)
                        } else {
                            addCategory(category)
                        }
                        Log.i(TAG, catName)
                    } else {
                        nameFieldError.value = "Duplicate item"
                    }
                }
                .addOnFailureListener {
                    Log.e(TAG, it.toString())
                }
        } else {
            nameFieldError.value = "Please enter this field"
        }
    }

    fun addCategory(category: Category) {
        firestore.collection("category")
            .add(category)
            .addOnSuccessListener {
                navigateToMenuFragment.value = true
            }
            .addOnFailureListener {
                Log.d(TAG, it.toString())
            }
    }

    fun updateCategory(category: Category) {
        firestore.document(id).set(category)
            .addOnSuccessListener {
                navigateToMenuFragment.value = true
            }
            .addOnFailureListener {
                Log.d(TAG, it.toString())
            }
    }
}