package com.example.bkmerchant.menu.dish

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bkmerchant.menu.Category
import com.example.bkmerchant.menu.Dish
import com.example.bkmerchant.menu.category.CategoryViewModel
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot

class DishViewModel(val id: String): ViewModel() {
    companion object {
        const val TAG = "DishViewModel"
    }

    private val firestore = FirebaseFirestore.getInstance()

    var name = MutableLiveData<String>()
    var description = MutableLiveData<String>()
    var price = MutableLiveData<String>()
    var imageUrl = ""

    var dish: Dish = Dish()
    var categories = mutableListOf<Category>()
    var catList = MutableLiveData<List<String>>()

    val emptyNameField = MutableLiveData<String>()
    val emptyPriceField = MutableLiveData<String>()

    var navigateToMenuFragment = MutableLiveData<Boolean>()

    init {
        if (id.isNotEmpty()) {
            firestore.document(id).get()
                .addOnSuccessListener {
                    dish = it.toObject(Dish::class.java)!!
                    bind()
                    Log.i(CategoryViewModel.TAG, "success: $id")
                }
                .addOnFailureListener {
                    Log.w(CategoryViewModel.TAG, it.toString())
                }
        }
        getCategoryList()
    }

    private fun bind() {
        name.value = dish.name
        description.value = dish.description
        price.value = dish.price.toString()
        imageUrl = dish.imageUrl
    }

    fun saveDish(url: String, index: Int) {
        if (url.isNotEmpty()) {
            imageUrl = url
        }
        val categoryPath = categories[index].id
        if (id.isNotEmpty()) {
            dish.imageUrl = imageUrl
            updateDish(categoryPath)
        } else {
            dish = Dish("",
                name.value ?: "",
                description.value ?: "",
                (price.value ?: "0").toDouble(),
                true,
                imageUrl)
            addDish(categoryPath)
        }
    }

    fun addDish(path: String) {
        firestore.collection(path + "/dish")
            .add(dish)
            .addOnSuccessListener {
                navigateToMenuFragment.value = true
            }
            .addOnFailureListener {
                Log.d(CategoryViewModel.TAG, it.toString())
            }
    }

    fun updateDish(path: String) {
        firestore.collection(path + "/dish")
            .add(dish)
            .addOnSuccessListener {
                navigateToMenuFragment.value = true
            }
            .addOnFailureListener {
                Log.d(CategoryViewModel.TAG, it.toString())
            }
    }

    fun getCategoryList(){
        val returnList = mutableListOf<String>()
        firestore.collection("category")
            .get()
            .addOnSuccessListener {querySnapshot ->
                if (querySnapshot != null) {
                    for (snapshot in querySnapshot) {
                        val item = snapshot.toObject(Category::class.java)
                        item.id = "category/" + snapshot.id

                        categories.add(item)
                        returnList.add(item.name)
                        Log.d(TAG, returnList[returnList.size-1])
                    }
                    catList.value = returnList.toList()
                } else {
                    Log.d(TAG, "empty result")
                }
            }
            .addOnFailureListener {
                Log.d(TAG, it.toString())
            }
    }
}