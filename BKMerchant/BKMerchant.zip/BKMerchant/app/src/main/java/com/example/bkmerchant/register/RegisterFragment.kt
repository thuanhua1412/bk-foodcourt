package com.example.bkmerchant.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.bkmerchant.R
import com.example.bkmerchant.databinding.LoginFragmentBinding
import com.example.bkmerchant.databinding.RegisterFragmentBinding
import com.example.bkmerchant.login.LoginViewModel
import com.google.firebase.auth.FirebaseAuth

class RegisterFragment : Fragment() {

    companion object {
        const val TAG = "RegisterFragment"
        const val REGISTER_RESULT_CODE = 1003
    }

    private lateinit var binding: RegisterFragmentBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()

        binding = RegisterFragmentBinding.inflate(inflater, container, false)
        binding.registerButton.setOnClickListener { register() }
        binding.signInTextView.setOnClickListener { navigateToLoginFragment() }
        return binding.root;
    }

    private fun register() {
        val email = binding.emailText.text.toString()
        val password = binding.passwordText.text.toString()
        val confirmPassword = binding.confirmPasswordText.text.toString()
        if (email.isEmpty()) {
            binding.emailText.setError("Empty email")
        } else if (password.isEmpty()) {
            binding.passwordText.setError("Empty password")
            binding.emailText.requestFocus()
        } else if (confirmPassword != password) {
            binding.confirmPasswordText.setError("Password not match")
            binding.confirmPasswordText.requestFocus()
        } else {
            firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if (task.isSuccessful()) {
                    Toast.makeText(context, "Register successful", Toast.LENGTH_SHORT).show()
                    navigateToLoginFragment()
                } else {
                    Toast.makeText(context, "Register failed, please try again", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
    }

    private fun navigateToLoginFragment() {
        findNavController().navigate(R.id.loginFragment)
    }
}